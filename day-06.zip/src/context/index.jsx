import { ProductsProvider } from "./productsContext"

export const CombineContextProvider = ({children}) => {

    return <ProductsProvider>
        {children}
    </ProductsProvider>
}